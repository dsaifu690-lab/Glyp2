plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Download Nothing's Glyph Matrix SDK during the build if it is not present yet
val glyphAar = file("libs/glyph-matrix-sdk-2.0.aar")
if (!glyphAar.exists()) {
    glyphAar.parentFile.mkdirs()
    val glyphIn = java.net.URL("https://raw.githubusercontent.com/Nothing-Developer-Programme/GlyphMatrix-Developer-Kit/main/glyph-matrix-sdk-2.0.aar").openStream()
    java.nio.file.Files.copy(glyphIn, glyphAar.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING)
    glyphIn.close()
}

android {
    namespace = "com.example.glyphbeat"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.glyphbeat"
        minSdk = 34
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(files("libs/glyph-matrix-sdk-2.0.aar"))
}
