package com.example.glyphbeat

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sqrt

/** Decodes an audio file and turns it into a bass / mid / high / beat timeline (40 frames per second). */
object Analyzer {
    const val FPS = 40
    const val HOP_MS = 25

    class Result(
        val bass: FloatArray,
        val mid: FloatArray,
        val high: FloatArray,
        val beat: BooleanArray,
        val signature: Int
    ) {
        val size: Int get() = bass.size
        val durationMs: Long get() = size.toLong() * HOP_MS
    }

    fun analyze(ctx: Context, uri: Uri, maxSeconds: Int = 900): Result {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        var track = -1
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) { track = i; break }
        }
        if (track < 0) { ex.release(); throw IllegalArgumentException("No audio track found") }
        ex.selectTrack(track)
        val fmt = ex.getTrackFormat(track)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)

        val bl = ArrayList<Float>()
        val ml = ArrayList<Float>()
        val hl = ArrayList<Float>()
        try {
            codec.configure(fmt, null, null, 0)
            codec.start()
            var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var hop = sr / FPS
            var a1 = (1 - exp(-2 * PI * 150 / sr)).toFloat()
            var a2 = (1 - exp(-2 * PI * 2000 / sr)).toFloat()
            var lp1 = 0f
            var lp2 = 0f
            var aB = 0f
            var aM = 0f
            var aH = 0f
            var n = 0
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            val maxFrames = maxSeconds * FPS
            while (!outDone && bl.size < maxFrames) {
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(5000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val sz = ex.readSampleData(buf, 0)
                        if (sz < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 5000)
                if (oi >= 0) {
                    val out = codec.getOutputBuffer(oi)!!
                    out.position(info.offset)
                    out.limit(info.offset + info.size)
                    val sb = out.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val total = sb.remaining()
                    var p = 0
                    while (p + ch <= total) {
                        var s = 0f
                        for (c in 0 until ch) s += sb.get(p + c).toFloat()
                        p += ch
                        val x = s / ch / 32768f
                        lp1 += a1 * (x - lp1)
                        lp2 += a2 * (x - lp2)
                        val b = lp1
                        val m = lp2 - lp1
                        val h = x - lp2
                        aB += b * b
                        aM += m * m
                        aH += h * h
                        n++
                        if (n >= hop) {
                            bl.add(sqrt(aB / n))
                            ml.add(sqrt(aM / n))
                            hl.add(sqrt(aH / n))
                            aB = 0f; aM = 0f; aH = 0f; n = 0
                        }
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = codec.outputFormat
                    sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    hop = sr / FPS
                    a1 = (1 - exp(-2 * PI * 150 / sr)).toFloat()
                    a2 = (1 - exp(-2 * PI * 2000 / sr)).toFloat()
                }
            }
        } finally {
            try { codec.stop() } catch (e: Throwable) { }
            codec.release()
            ex.release()
        }
        if (bl.size < 10) throw IllegalArgumentException("Audio too short or unreadable")

        val bass = norm(bl)
        val mid = norm(ml)
        val high = norm(hl)
        val beat = BooleanArray(bass.size)
        var last = -100
        for (i in bass.indices) {
            val from = maxOf(0, i - 40)
            var avg = 0f
            for (j in from until i) avg += bass[j]
            avg /= maxOf(1, i - from)
            if (bass[i] > avg * 1.3f + 0.08f && bass[i] > 0.4f && i - last > 8 &&
                (i == 0 || bass[i] >= bass[i - 1])
            ) {
                beat[i] = true
                last = i
            }
        }
        val sig = abs((bass.sum() * 1000).toInt())
        return Result(bass, mid, high, beat, sig)
    }

    private fun norm(l: ArrayList<Float>): FloatArray {
        val a = l.toFloatArray()
        val sorted = a.sortedArray()
        val p = sorted[(sorted.size * 0.98f).toInt().coerceAtMost(sorted.size - 1)].coerceAtLeast(1e-6f)
        for (i in a.indices) a[i] = (a[i] / p).coerceIn(0f, 1f).pow(0.7f)
        return a
    }
}
