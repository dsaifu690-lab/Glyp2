package com.example.glyphbeat

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var styleSpinner: Spinner
    private lateinit var offsetBox: EditText
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(pad, pad, pad, pad)
        }
        fun label(t: String) = TextView(this).apply {
            text = t.uppercase()
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, pad / 2, 0, 0)
        }
        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { save(); onClick() }
        }

        status = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            setTextColor(Color.WHITE)
            text = prefs.getString("name", null)?.let { "Song: $it" } ?: "No song picked yet"
        }
        styleSpinner = Spinner(this)
        styleSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Renderer.STYLES)
        styleSpinner.setSelection(prefs.getInt("style", 0))
        offsetBox = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            setText(prefs.getInt("offset", 0).toString())
            setSingleLine()
        }

        root.addView(TextView(this).apply {
            text = "● GLYPH BEAT"
            typeface = Typeface.MONOSPACE
            setTextColor(Color.rgb(215, 25, 33))
            textSize = 22f
        })
        root.addView(status)
        root.addView(button("1. Pick song / ringtone file") {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*")
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION),
                10
            )
        })
        root.addView(label("Pattern style")); root.addView(styleSpinner)
        root.addView(label("Sync offset in ms (negative = earlier)")); root.addView(offsetBox)
        root.addView(button("Preview: play song with Glyph") {
            startForegroundService(Intent(this, GlyphService::class.java).setAction("PLAY"))
        })
        root.addView(button("Stop preview") {
            startForegroundService(Intent(this, GlyphService::class.java).setAction("STOP"))
        })
        root.addView(button("2. Use this song as my phone ringtone") { setAsRingtone() })
        root.addView(button("3. Allow permissions") {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.POST_NOTIFICATIONS), 1)
        })
        root.addView(button("4. Glyph on incoming calls: ON") {
            startForegroundService(Intent(this, GlyphService::class.java).setAction("WATCH_ON"))
            toast("Call watching is on")
        })
        root.addView(button("Glyph on incoming calls: OFF") {
            startForegroundService(Intent(this, GlyphService::class.java).setAction("WATCH_OFF"))
            toast("Call watching is off")
        })
        root.addView(label("Tip: if Nothing's built-in ringtone glyph keeps drawing over this, turn it off in Settings > Glyph Interface."))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(root)
        })
    }

    private fun save() {
        prefs.edit()
            .putInt("style", styleSpinner.selectedItemPosition)
            .putInt("offset", offsetBox.text.toString().toIntOrNull() ?: 0)
            .apply()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun setStatus(t: String) = main.post { status.text = t }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != 10 || resultCode != RESULT_OK || uri == null) return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Throwable) {
        }
        var name = "song"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        prefs.edit().putString("uri", uri.toString()).putString("name", name).apply()
        setStatus("Analyzing $name ...")
        Store.ensure(this) { r, err ->
            setStatus(
                if (r != null) "Ready: $name\n${r.durationMs / 1000}s, ${r.beat.count { it }} beats found"
                else "Could not read this file: $err"
            )
        }
    }

    private fun setAsRingtone() {
        val src = prefs.getString("uri", null)?.let { Uri.parse(it) }
        if (src == null) { toast("Pick a song first"); return }
        if (!Settings.System.canWrite(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            toast("Allow it, go back, then tap again")
            return
        }
        val name = prefs.getString("name", "glyph_ringtone.mp3") ?: "glyph_ringtone.mp3"
        Thread {
            try {
                val cv = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, contentResolver.getType(src) ?: "audio/mpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_RINGTONES)
                    put(MediaStore.Audio.Media.IS_RINGTONE, 1)
                    put(MediaStore.Audio.Media.IS_MUSIC, 0)
                }
                val dst = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: throw RuntimeException("Could not create ringtone entry")
                contentResolver.openOutputStream(dst)!!.use { o ->
                    contentResolver.openInputStream(src)!!.use { it.copyTo(o) }
                }
                RingtoneManager.setActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE, dst)
                main.post { toast("Ringtone set") }
            } catch (e: Throwable) {
                main.post { toast("Failed: ${e.message}") }
            }
        }.start()
    }
}
