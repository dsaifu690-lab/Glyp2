package com.example.glyphbeat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.widget.Toast

class GlyphService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var out: MatrixOut
    private var player: MediaPlayer? = null
    private var watching = false
    private var ringing = false
    private var ringStart = 0L
    private var looping = false
    private var callback: TelephonyCallback? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        out = MatrixOut(this)
        out.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("glyph", "Glyph Beat", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "glyph")
            .setContentTitle("Glyph Beat is active")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        when (intent?.action) {
            "PLAY" -> startPlayback()
            "STOP" -> stopPlayback()
            "WATCH_ON" -> watchOn()
            "WATCH_OFF" -> watchOff()
        }
        main.post { checkStop() }
        return START_NOT_STICKY
    }

    private fun prefs() = getSharedPreferences("cfg", Context.MODE_PRIVATE)

    private fun startPlayback() {
        Store.ensure(this) { r, err ->
            main.post {
                if (r == null) {
                    Toast.makeText(this, "Can't use that file: $err", Toast.LENGTH_LONG).show()
                    checkStop()
                    return@post
                }
                try {
                    player?.release()
                    val mp = MediaPlayer()
                    mp.setDataSource(this, Uri.parse(Store.uri(this)))
                    mp.setOnCompletionListener { stopPlayback() }
                    mp.prepare()
                    mp.start()
                    player = mp
                    kick()
                } catch (e: Throwable) {
                    Toast.makeText(this, "Playback failed: ${e.message}", Toast.LENGTH_LONG).show()
                    checkStop()
                }
            }
        }
    }

    private fun stopPlayback() {
        player?.release()
        player = null
        main.post { checkStop() }
    }

    private fun watchOn() {
        if (watching) return
        try {
            val tm = getSystemService(TelephonyManager::class.java)
            val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) {
                    main.post {
                        if (state == TelephonyManager.CALL_STATE_RINGING) {
                            ringing = true
                            ringStart = SystemClock.elapsedRealtime()
                            Store.ensure(this@GlyphService) { _, _ -> main.post { kick() } }
                        } else {
                            ringing = false
                        }
                    }
                }
            }
            tm.registerTelephonyCallback(mainExecutor, cb)
            callback = cb
            watching = true
        } catch (e: Throwable) {
            Toast.makeText(this, "Allow the Phone permission first", Toast.LENGTH_LONG).show()
        }
    }

    private fun watchOff() {
        try {
            callback?.let { getSystemService(TelephonyManager::class.java).unregisterTelephonyCallback(it) }
        } catch (e: Throwable) {
        }
        callback = null
        watching = false
        ringing = false
    }

    private fun checkStop() {
        if (!watching && player == null) {
            out.clear()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun kick() {
        if (!looping) {
            looping = true
            main.post { loop() }
        }
    }

    private fun loop() {
        val r = Store.result
        val p = prefs()
        val offset = p.getInt("offset", 0)
        val pos: Long? = when {
            player != null && r != null -> try { player!!.currentPosition.toLong() + offset } catch (e: Throwable) { null }
            ringing && r != null -> {
                val dur = maxOf(1L, r.durationMs)
                (((SystemClock.elapsedRealtime() - ringStart + offset) % dur) + dur) % dur
            }
            else -> null
        }
        if (pos == null || r == null) {
            out.clear()
            looping = false
            return
        }
        val idx = (pos.coerceAtLeast(0) / Analyzer.HOP_MS).toInt()
        out.show(Renderer.render(r, idx, p.getInt("style", 0)))
        main.postDelayed({ loop() }, 40)
    }

    override fun onDestroy() {
        watchOff()
        player?.release()
        player = null
        out.stop()
        super.onDestroy()
    }
}
